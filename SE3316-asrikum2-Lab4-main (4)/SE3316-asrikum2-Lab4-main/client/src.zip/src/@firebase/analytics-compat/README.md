# @firebase/analytics-compat

This is the compatibility layer for the Firebase Analytics component of the Firebase JS SDK.

**This package is not intended for direct usage, and should only be used via the officially supported [firebase](https://www.npmjs.com/package/firebase) package.**
