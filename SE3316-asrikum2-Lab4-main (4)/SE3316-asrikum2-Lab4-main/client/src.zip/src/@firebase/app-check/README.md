# @firebase/app-check

This is the Firebase App Check component of the Firebase JS SDK.

**This package is not intended for direct usage, and should only be used via the officially supported [`firebase`](https://www.npmjs.com/package/firebase) package.**
